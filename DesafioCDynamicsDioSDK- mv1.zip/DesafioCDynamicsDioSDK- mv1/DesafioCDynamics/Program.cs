﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesafioCDynamics
{
    public class Program
    {
        static void Main(string[] args)
        {
            var crmService = new Conexao().ObterConexao();
            DataModel dataModel = new DataModel();
            dataModel.UpdateEntity(crmService, new Guid("b4cea450-cb0c-ea11-a813-000d3a1b1223"));
            dataModel.DeleteEntity(crmService, new Guid("48c32252-e679-ee11-8178-002248d30596"));
        }
    }
}
